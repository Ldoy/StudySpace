import UIKit
/*1. 이해
내가 이해한 문제해설 작성
2. 계획
코드를 어떻게 작성할건지 작성
3. 실행
테스트코드 작성
4. 회고
 */
//: # Lesson 2 Exercises
//: ## Optionals
//: ### Exercise 1
//: When retrieving a value from a dictionary, Swift returns an optional.
//:
//: 1a) The variable, director, is an optional type. Its value cannot be used until it is unwrapped. Use `if let` to carefully unwrap the value returned by `moviesDict[movie]`
var moviesDict:Dictionary = [ "Star Wars":"George Lucas", "Point Break":"Kathryn Bigelow"]
var movie = "Point Break"
//var director = moviesDict[movie]

//if let movies = director {
//    print(movies)
//}else {
//    print("nil")
//}

movie = "Star Wars"
var director = moviesDict[movie]

if let movies = director {
    print(movies)
}else {
    print("nil")
}

//: 1b) Test your code by inserting different values for the variable `movie`.
/*1. 이해
1a) optional type을 unwrapping 할 때 let을 이용하여 optional binding 이용하여 nil값이 있더라도 error가 생기지 않게 unwrapping 하는 방법을 작성하고 return value를 moviesDict[movie]로 선언하여라.
 1b) moviesDict에 다른 값을 insert하는 방식으로 1a의 code가 정상적으로 binding 되어있는지 확인하기.
 
 2. 계획
1a) if let binding을 이용하여 값이 있는 경우에만 moviesDict[movie]가 return되도록 작성 한다.
1b) 1a 코드 실행후 moviesDict에 insert method 실행
 
 3. 실행
 var moviesDict:Dictionary = [ "Star Wars":"George Lucas", "Point Break":"Kathryn Bigelow"]
 var movie = "Point Break"
 //var director = moviesDict[movie]

 //if let movies = director {
 //    print(movies)
 //}else {
 //    print("nil")
 //}

 movie = "Star Wars"
 var director = moviesDict[movie]

 if let movies = director {
     print(movies)
 }else {
     print("nil")
 }
 4. 회고
 if 대신 guard, while을 써야하는 이유를 생각해 보지 않았다. 1a를 진행한 후 1b를 진행하니 movie variable은 Star Wars 로 바뀌었지만 if binding 에서 계속 1a와 동일한 Kathryn Bigelow 가 나왔다. (이유를 모르겠음)
-> guards, while binding 차이점 정리하기
 */
//: ### Exercise 2
//: The LoginViewController class below needs a UITextField to hold a user's name. Declare a variable for this text field as a property of the class LoginViewController. Keep in mind that the textfield property will not be initialized until after the view controller is constructed.
class LoginViewController: UIViewController {
}
class UITextField: LoginViewController {
}
let myTextField: UITextField = UITextField()




/*1. 이해
: LoginViewController(LVC)는 UIViewController type이며 class object 이다.
 사용자 이름을 입력하기 위한 textfield구현을 위해 UITextField(UITF) property가 필요하다. 이를 위한 variable을 LVC 클래스 내부에 선언하여라.(텍스트필드 속성은 view controller가 만들어지기 이전엔 초기화되지 않는다.)
 2. 계획
UITextField는 UIControl 타입이며
 textfield를 만드는 var 선언 후 init()
 
 3. 실행
 
 4. 회고
 init 개념과 class 개념 완벽히 이해가 안되었음을 알게되었다.
 
 // Solution
 //class LoginViewController: UIViewController {
 //    var nameTextfield:UITextField!
 //}
 */

//: ### Exercise 3
//: The Swift Int type has an initializer that takes a string as a parameter and returns an optional of type Int?.
//:
//: 3a) Finish the code below by safely unwrapping the constant, `number`.
var numericalString = "3"
var number = Int(numericalString)
//TODO: Unwrap number to make the following print statement more readable.
print("\(number) is the magic number.")

if let a = number, a == 3 {
    print("\(a) is the magic number.")
}

/*1. 이해
number를 unwarapping 하기
 2. 계획
if let binding 이용

 3. 실행
 if let a = number, a == 3 {
     print("\(a) is the magic number.")
 }
 4. 회고
 더 가독성이 높게 하는 방법을 모르겠다.
 
 // Solution
 if let number = number {
     print("\(number) is the magic number.")
 } else {
     print("No magic numbers here.")
 }
 
 */

//: 3b) Change the value of numericalString to "three" and execute the playground again.
//var numericalString = "three"
//var number = Int(numericalString)
////TODO: Unwrap number to make the following print statement more readable.
//print("\(number) is the magic number.")
//
//if let a = number, a == 3 {
//    print("\(a) is the magic number.")
//} else{
//    print("nil")
//}
//: ### Exercise 4
//: The class UIViewController has a property called tabBarController.  The tabBarController property is an optional of type UITabBarController?. The tabBarController itself holds a tabBar as a property. Complete the code below by filling in the appropriate use of optional chaining to access the tab bar property.
var viewController = UIViewController()
if viewController.tabBarController != nil {
    print("Here's the tab bar.")
} else {
    print("No tab bar controller found.")
}

// Solution
//if let tabBar = viewController.tabBarController?.tabBar {
//    print("Here's the tab bar.")
//} else {
//    print("No tab bar controller found.")
//}


/*1. 이해
tabbar property는 UITableBarController의 Optional type이기 때문에 safely unwrapping 이 필요하다.이를 위해 if let optioanl binding 진행
 
 2. 계획
코드를 어떻게 작성할건지 작성
3. 실행
 if viewController.tabBarController != nil {
     print("Here's the tab bar.")
 } else {
     print("No tab bar controller found.")
 }
4. 회고
 swift 에서 if let 보다 if viewController.tabBarController != nil 를 추천한 이유는 무엇인가 고민해야한다.
 optioanal chaining 으로 solution 진행하였는데 둘 중 무엇이 좋은 것일까?
 -> optioanl chaining 왜 써야하는지
 */



//: ### Exercise 5
//: Below is a dictionary of paintings and artists.
//:
//: 5a) The variable, artist, is an optional type. Its value cannot be used until it is unwrapped. Use `if let` to carefully unwrap the value returned by `paintingDict[painting]`.

//var paintingDict:Dictionary = [ "Guernica":"Picasso", "Mona Lisa": "da Vinci", "No. 5": "Pollock"]
//var painting = "Mona Lisa"
//var artist = paintingDict[painting]
//
//if let artists = artist, artists == "da Vinci" {
//    print(paintingDict[painting] ?? "nil")
//}else {
//    print("This is nil")
//}

/*1. 이해
 optional varaible인 artist를 if let 을 이용하여 sately unwrapping 하고 성공시에  paintingDict[painting]을 return 하여라

 2. 계획
 if let  이용하여 optional binding 진행
 3. 실행
 if let artists = artist, artists == "da Vinci" {
     print(paintingDict[painting])
 }else {
     print("This is nil")
 }
4. 회고
 위의 코드를 실행한 결과 정상 적으로 값이 return 되었지만
 if let artists = artist, artists == "da Vinci" {
     print(paintingDict[painting] ?? "nil")
 }else {
     print("This is nil")
 }
 아래와 같이 Nil-Coalescing Operator 설정하라고 권고하였다. 이유는 paintingDict[painting] 가 optional 이기 때문에 nil을 return할 경우 오류가 생길 수 있기 때문에 default 를 설정하라고 권고 한것
 */
//: 5b) Test your code by inserting different values for the variable `painting`.
var paintingDict:Dictionary = [ "Guernica":"Picasso", "Mona Lisa": "da Vinci", "No. 5": "Pollock"]
var painting = "Guernica"
var artist = paintingDict[painting]

if let artists = artist, artists == "da Vinci" {
    print(paintingDict[painting] ?? "nil")
}else {
    print("This is nil")
}


/*1. 이해
painting에 다른 값을 assign하여 코드 정상 작동되는지 확인하기
 2. 계획
painting variable에 "Guernica" assign
 3. 실행
 if let artists = artist, artists == "da Vinci" {
     print(paintingDict[painting] ?? "nil")
 }else {
     print("This is nil")
 } // This is nil 가 콘솔에 표시
 4. 회고
 variable을 변경함으로 정상 작동 되는 것을 확인 할 수 있었다.
 */
//: ### Exercise 6
//: Set the width of the cancel button below.  Notice that the cancelButton variable is declared as an implicitly unwrapped optional.
var anotherViewController = UIViewController()
var cancelButton: UIBarButtonItem!
cancelButton = UIBarButtonItem()
// TODO: Set the width of the cancel button.

cancelButton.width = 20


/*1. 이해
 optional type 인 cancel button의 property를 선언하여라
 2. 계획
optional type에 property를 선언하는 방법인 optional chain이용한다.
 3. 실행
 cancelButton?.width = 20
 4. 회고
 
 
 */

//: ### Exercise 7
//: The class UIViewController has a property called parent.  The parent property is an optional of type UIViewController?. We can't always be sure that a given view controller has a parent view controller.  Safely unwrap the parent property below using if let.
var childViewController = UIViewController()
// TODO: Safely unwrap childViewController.parent
if childViewController.parent != nil {
    print("It works!")
}else {
    print("nil")
}



/*1. 이해
 UIViewController는 parent property를 가지고 있는데 이는 Optional type 이기 때문에 UIVIewController.parent를 사용할 때 unwrapping 필요하다.
 2. 계획
if let 이용
 3. 실행
 if childViewController.parent != nil {
     print("It works!")
 }else {
     print("nil")
 }
 4. 회고

 */
